#include "autopilot.h"
#include "mainwindow.h"

#include <QComboBox>
#include <QDir>
#include <QDoubleSpinBox>
#include <QGraphicsPathItem>
#include <QGraphicsPolygonItem>
#include <QGraphicsView>
#include <QLabel>
#include <QListWidget>
#include <QMessageBox>
#include <QPushButton>
#include <QSignalSpy>
#include <QTableWidget>
#include <QTabWidget>
#include <QTest>
#include <QTimer>
#include <cmath>

class GroundStationTest : public QObject
{
    Q_OBJECT
private:
    static void click(MainWindow &window, const char *name)
    {
        auto *button = window.findChild<QPushButton *>(QString::fromLatin1(name));
        QVERIFY2(button, name);
        button->click();
        QCoreApplication::processEvents();
    }

    static void cycles(MainWindow &window, int count)
    {
        auto *timer = window.findChild<QTimer *>(QStringLiteral("cycleTimer"));
        for (int i = 0; i < count; ++i)
            QMetaObject::invokeMethod(timer, "timeout", Qt::DirectConnection);
        QCoreApplication::processEvents();
    }

    static void screenshot(MainWindow &window, const QString &name)
    {
        const QString directory = qEnvironmentVariable("GROUNDSTATION_SCREENSHOT_DIR");
        if (directory.isEmpty())
            return;
        QDir().mkpath(directory);
        QCoreApplication::processEvents();
        QVERIFY(window.grab().save(directory + "/" + name + ".png"));
    }

private slots:
    void initTestCase()
    {
        QApplication::setStyle(QStringLiteral("Fusion"));
    }

    void navigation_priority_and_total_failure()
    {
        NavigationManager manager;
        QSignalSpy changed(&manager, &NavigationManager::active_system_changed);
        QVERIFY(manager.update_active_system());
        QCOMPARE(manager.active_name(), QStringLiteral("GPS"));
        manager.set_gps_valid(false);
        QVERIFY(manager.update_active_system());
        QCOMPARE(manager.active_name(), QStringLiteral("INS"));
        manager.set_ins_valid(false);
        QVERIFY(manager.update_active_system());
        QCOMPARE(manager.active_name(), QStringLiteral("Visual"));
        manager.set_visual_valid(false);
        QVERIFY(!manager.update_active_system());
        QCOMPARE(changed.count(), 3);
        manager.restore();
        QCOMPARE(manager.active_name(), QStringLiteral("GPS"));
    }

    void commands_pid_and_fault_latching()
    {
        Autopilot autopilot(QStringLiteral("Тест"), std::make_unique<Quadcopter>(), 155.0, 0.0);
        QSignalSpy modes(&autopilot, &Autopilot::mode_changed);
        QSignalSpy telemetry(&autopilot, &Autopilot::telemetry_updated);
        QSignalSpy faults(&autopilot, &Autopilot::fault_detected);
        autopilot.command_takeoff();
        QCOMPARE(autopilot.target_altitude(), 200.0);
        QCOMPARE(autopilot.mode(), Autopilot::Mode::Takeoff);
        for (int i = 0; i < 600; ++i)
            autopilot.run_cycle();
        QVERIFY(std::abs(autopilot.altitude() - 200.0) < 1.0);
        QCOMPARE(autopilot.mode(), Autopilot::Mode::Hold);
        autopilot.set_target_altitude(300.0);
        QVERIFY(telemetry.last()[2].toDouble() > 95.0);
        for (int i = 0; i < 600; ++i)
            autopilot.run_cycle();
        QVERIFY(std::abs(autopilot.altitude() - 300.0) < 1.0);
        autopilot.set_target_altitude(std::nan(""));
        QCOMPARE(autopilot.target_altitude(), 300.0);

        autopilot.set_gyroscope_ready(false);
        const int beforeFault = telemetry.count();
        autopilot.run_cycle();
        QVERIFY(autopilot.has_fault());
        QCOMPARE(faults.count(), 1);
        for (int i = 0; i < 10; ++i)
            autopilot.run_cycle();
        QCOMPARE(faults.count(), 1);
        QCOMPARE(telemetry.count(), beforeFault);
        autopilot.command_takeoff();
        QCOMPARE(autopilot.mode(), Autopilot::Mode::Fault);
        autopilot.reset_faults();
        QVERIFY(!autopilot.has_fault());
        autopilot.command_land();
        QCOMPARE(autopilot.target_altitude(), 0.0);
        for (int i = 0; i < 1200; ++i)
            autopilot.run_cycle();
        QCOMPARE(autopilot.mode(), Autopilot::Mode::Landed);
        QCOMPARE(autopilot.altitude(), 0.0);
        autopilot.command_takeoff();
        for (int i = 0; i < 30; ++i)
            autopilot.run_cycle();
        autopilot.command_stop();
        const double stoppedAt = autopilot.altitude();
        const double stoppedTime = autopilot.elapsed_seconds();
        autopilot.run_cycle();
        QCOMPARE(autopilot.mode(), Autopilot::Mode::Stopped);
        QCOMPARE(autopilot.altitude(), stoppedAt);
        QCOMPARE(autopilot.elapsed_seconds(), stoppedTime);
        QVERIFY(modes.count() >= 7);

        Autopilot missingVehicle(QStringLiteral("Пустой"), nullptr, 1.0, 0.0);
        QSignalSpy missingFault(&missingVehicle, &Autopilot::fault_detected);
        missingVehicle.resume();
        missingVehicle.run_cycle();
        QCOMPARE(missingFault.count(), 1);
    }

    void large_error_and_compact_layout()
    {
        MainWindow window;
        window.resize(1080, 720);
        window.show();
        QTest::qWait(100);
        QCOMPARE(window.size(), QSize(1080, 720));
        auto *target = window.findChild<QDoubleSpinBox *>("spinTarget");
        auto *chartView = window.findChild<Charts::QChartView *>("chartView");
        target->setValue(500.0);
        const auto axes = chartView->chart()->axes(Qt::Vertical);
        auto *axis = qobject_cast<Charts::QValueAxis *>(axes.first());
        QVERIFY(axis && axis->max() >= 500.0);
        for (const char *name : {"btnStart", "btnPause", "btnReset", "btnTakeoff",
                                  "btnLand", "btnStop", "graphicsView", "tableFleet"}) {
            auto *widget = window.findChild<QWidget *>(name);
            QVERIFY(widget && widget->isVisible());
            QVERIFY(window.rect().contains(QRect(widget->mapTo(&window, QPoint()), widget->size())));
        }
        screenshot(window, QStringLiteral("08_compact_1080x720"));
    }

    void widgets_integration_and_screenshots()
    {
        MainWindow window;
        window.show();
        QTest::qWait(100);
        auto models = window.findChildren<Autopilot *>();
        QCOMPARE(models.size(), 2);
        auto *timer = window.findChild<QTimer *>(QStringLiteral("cycleTimer"));
        auto *status = window.findChild<QLabel *>(QStringLiteral("labelStatus"));
        auto *selector = window.findChild<QComboBox *>(QStringLiteral("comboAircraft"));
        auto *fleet = window.findChild<QTableWidget *>(QStringLiteral("tableFleet"));
        auto *target = window.findChild<QDoubleSpinBox *>(QStringLiteral("spinTarget"));
        auto *events = window.findChild<QListWidget *>(QStringLiteral("listEvents"));
        QVERIFY(timer && status && selector && fleet && target && events);
        QCOMPARE(timer->interval(), 100);
        QVERIFY(!timer->isActive());
        QCOMPARE(fleet->rowCount(), 2);
        QVERIFY(status->text().contains("Stopped"));
        screenshot(window, QStringLiteral("00_initial"));

        QSignalSpy first(models[0], &Autopilot::telemetry_updated);
        QSignalSpy second(models[1], &Autopilot::telemetry_updated);
        click(window, "btnStart");
        QTest::qWait(360);
        QVERIFY(first.count() >= 3 && first.count() <= 5);
        QCOMPARE(first.count(), second.count());
        click(window, "btnPause");
        QVERIFY(status->text().contains("Paused"));
        const double pausedAt = models[0]->altitude();
        QTest::qWait(220);
        QCOMPARE(models[0]->altitude(), pausedAt);
        click(window, "btnStart");
        cycles(window, 270);
        QVERIFY(models[0]->altitude() > 190.0);
        QVERIFY(models[1]->altitude() > 190.0);
        QCOMPARE(models[0]->elapsed_seconds(), models[1]->elapsed_seconds());

        auto *scene = window.findChild<QGraphicsView *>(QStringLiteral("graphicsView"))->scene();
        QGraphicsPolygonItem *marker = nullptr;
        QGraphicsPathItem *trajectory = nullptr;
        for (auto *item : scene->items()) {
            if (item->data(0).toString() == "marker0")
                marker = qgraphicsitem_cast<QGraphicsPolygonItem *>(item);
            if (item->data(0).toString() == "trajectory0")
                trajectory = qgraphicsitem_cast<QGraphicsPathItem *>(item);
        }
        QVERIFY(marker && trajectory);
        const int sceneItemCount = scene->items().size();
        const QPointF previousPosition = marker->pos();
        const int previousElements = trajectory->path().elementCount();
        cycles(window, 10);
        QVERIFY(marker->pos() != previousPosition);
        QVERIFY(std::abs(marker->rotation()) > 0.1);
        QVERIFY(trajectory->path().elementCount() > previousElements);
        QCOMPARE(scene->items().size(), sceneItemCount);
        screenshot(window, QStringLiteral("01_running"));

        const double oldError = 300.0 - models[0]->altitude();
        target->setValue(300.0);
        QCOMPARE(models[0]->target_altitude(), 300.0);
        QCOMPARE(models[1]->target_altitude(), 300.0);
        QVERIFY(first.last()[2].toDouble() > 95.0);
        cycles(window, 200);
        QVERIFY(std::abs(300.0 - models[0]->altitude()) < 2.0);
        QVERIFY(std::abs(300.0 - models[1]->altitude()) < 2.0);
        QVERIFY(std::abs(first.last()[2].toDouble()) < std::abs(oldError));
        screenshot(window, QStringLiteral("04_target_300"));

        click(window, "btnFaultGps");
        cycles(window, 1);
        QCOMPARE(models[0]->active_navigation(), QStringLiteral("INS"));
        QCOMPARE(models[1]->active_navigation(), QStringLiteral("INS"));
        QVERIFY(timer->isActive());
        QVERIFY(window.findChild<QLabel *>("labelNavigation")->styleSheet().contains("fff2c6"));
        screenshot(window, QStringLiteral("03_gps_fallback"));
        click(window, "btnRestoreGps");
        cycles(window, 1);
        QCOMPARE(models[0]->active_navigation(), QStringLiteral("GPS"));

        selector->setCurrentIndex(1);
        click(window, "btnFaultSensor");
        cycles(window, 1);
        QVERIFY(models[0]->has_fault());
        QVERIFY(!timer->isActive());
        QVERIFY(status->text().contains(QStringLiteral("Гироскоп")));
        QVERIFY(status->styleSheet().contains("ad2525"));
        auto *warning = window.findChild<QMessageBox *>("faultWarning");
        QVERIFY(warning && warning->isVisible());
        QVERIFY(warning->text().contains(QStringLiteral("Гироскоп")));
        QVERIFY(events->item(events->count() - 1)->text().contains(QStringLiteral("АВАРИЯ")));
        const double otherTime = models[1]->elapsed_seconds();
        cycles(window, 5);
        QCOMPARE(models[1]->elapsed_seconds(), otherTime);
        screenshot(window, QStringLiteral("02_sensor_fault"));
        const QString directory = qEnvironmentVariable("GROUNDSTATION_SCREENSHOT_DIR");
        if (!directory.isEmpty())
            QVERIFY(warning->grab().save(directory + "/02_fault_dialog.png"));
        warning->accept();
        QCoreApplication::processEvents();

        const double savedAltitude = models[0]->altitude();
        click(window, "btnReset");
        QVERIFY(timer->isActive());
        QVERIFY(!models[0]->has_fault());
        QCOMPARE(models[0]->altitude(), savedAltitude);
        QVERIFY(status->styleSheet().contains("177347"));
        cycles(window, 20);
        const double beforeRepeatedReset = models[0]->elapsed_seconds();
        click(window, "btnReset");
        QVERIFY(timer->isActive());
        QVERIFY(models[0]->elapsed_seconds() >= beforeRepeatedReset);
        screenshot(window, QStringLiteral("05_reset"));

        selector->setCurrentIndex(0);
        click(window, "btnLand");
        for (auto *model : models) {
            QCOMPARE(model->target_altitude(), 0.0);
            QCOMPARE(model->mode(), Autopilot::Mode::Landing);
        }
        cycles(window, 1100);
        for (auto *model : models) {
            QCOMPARE(model->altitude(), 0.0);
            QCOMPARE(model->mode(), Autopilot::Mode::Landed);
        }
        screenshot(window, QStringLiteral("06_landed"));
        click(window, "btnTakeoff");
        cycles(window, 30);
        for (auto *model : models)
            QCOMPARE(model->target_altitude(), 200.0);
        selector->setCurrentIndex(1);
        click(window, "btnStop");
        const double firstTime = models[0]->elapsed_seconds();
        const double secondTime = models[1]->elapsed_seconds();
        cycles(window, 5);
        QCOMPARE(models[0]->elapsed_seconds(), firstTime);
        QVERIFY(models[1]->elapsed_seconds() > secondTime);
        selector->setCurrentIndex(0);
        click(window, "btnStop");
        QVERIFY(!timer->isActive());
        QCOMPARE(models[0]->mode(), Autopilot::Mode::Stopped);
        QCOMPARE(models[1]->mode(), Autopilot::Mode::Stopped);
        screenshot(window, QStringLiteral("07_stop"));
        QCOMPARE(scene->items().size(), sceneItemCount);
    }
};

QTEST_MAIN(GroundStationTest)
#include "test_groundstation.moc"
