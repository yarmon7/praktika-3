cmake_minimum_required(VERSION 3.16)
project(Practical_03_GroundStation VERSION 1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTOUIC ON)
set(CMAKE_AUTORCC ON)

find_package(QT NAMES Qt6 Qt5 REQUIRED COMPONENTS Widgets Charts)
find_package(Qt${QT_VERSION_MAJOR} REQUIRED COMPONENTS Widgets Charts)

# Модель зависит только от Qt Core: виджетов и формул в окне нет.
add_library(groundstation_model STATIC
    uav.h uav.cpp sensor.h sensor.cpp navigation.h navigation.cpp
    controller.h controller.cpp autopilot.h autopilot.cpp)
target_link_libraries(groundstation_model PUBLIC Qt${QT_VERSION_MAJOR}::Core)
target_include_directories(groundstation_model PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})

set(WINDOW_SOURCES mainwindow.h mainwindow.cpp mainwindow.ui chartscompat.h)
add_executable(Practical_03_GroundStation MACOSX_BUNDLE WIN32
    main.cpp ${WINDOW_SOURCES})
target_link_libraries(Practical_03_GroundStation PRIVATE groundstation_model
    Qt${QT_VERSION_MAJOR}::Widgets Qt${QT_VERSION_MAJOR}::Charts)
set_target_properties(Practical_03_GroundStation PROPERTIES
    MACOSX_BUNDLE_GUI_IDENTIFIER ru.mirea.practical03
    MACOSX_BUNDLE_BUNDLE_NAME "Practical 03 Ground Station")

option(BUILD_TESTING "Build automated checks" OFF)
if(BUILD_TESTING)
    enable_testing()
    find_package(Qt${QT_VERSION_MAJOR} REQUIRED COMPONENTS Test)
    add_executable(groundstation_tests tests/test_groundstation.cpp ${WINDOW_SOURCES})
    target_link_libraries(groundstation_tests PRIVATE groundstation_model
        Qt${QT_VERSION_MAJOR}::Widgets Qt${QT_VERSION_MAJOR}::Charts
        Qt${QT_VERSION_MAJOR}::Test)
    add_test(NAME groundstation_tests COMMAND groundstation_tests)
    set_tests_properties(groundstation_tests PROPERTIES
        ENVIRONMENT "QT_QPA_PLATFORM=offscreen")
endif()
