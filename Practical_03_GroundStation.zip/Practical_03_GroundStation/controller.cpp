#include "controller.h"

#include <algorithm>

PIDController::PIDController(double kp, double ki, double kd) : kp_(kp), ki_(ki), kd_(kd) {}

double PIDController::calculate(double error, double dt, double limit)
{
    if (dt <= 0.0 || limit <= 0.0)
        return 0.0;
    const double derivative = firstCycle_ ? 0.0 : (error - previousError_) / dt;
    const double candidateIntegral = integral_ + error * dt;
    const double candidate = kp_ * error + ki_ * candidateIntegral + kd_ * derivative;
    // Не накапливаем интеграл, когда выход уже насыщен в сторону ошибки.
    if (!((candidate > limit && error > 0.0) || (candidate < -limit && error < 0.0)))
        integral_ = candidateIntegral;
    previousError_ = error;
    firstCycle_ = false;
    return std::clamp(kp_ * error + ki_ * integral_ + kd_ * derivative, -limit, limit);
}

void PIDController::reset()
{
    integral_ = 0.0;
    previousError_ = 0.0;
    firstCycle_ = true;
}
