#ifndef UAV_H
#define UAV_H

#include <QString>

class UAV
{
public:
    virtual ~UAV() = default;
    virtual QString type() const = 0;
    virtual int motor_count() const = 0;
    virtual double max_vertical_speed() const = 0;
    virtual double response_time() const = 0;

    double altitude() const;
    double battery() const;
    void advance(double verticalCommand, double dt);
    void hold_position();
    void touch_down();

private:
    double altitude_ = 0.0;
    double verticalSpeed_ = 0.0;
    double battery_ = 100.0;
};

class Quadcopter final : public UAV
{
public:
    QString type() const override;
    int motor_count() const override;
    double max_vertical_speed() const override;
    double response_time() const override;
};

class FixedWingUAV final : public UAV
{
public:
    QString type() const override;
    int motor_count() const override;
    double max_vertical_speed() const override;
    double response_time() const override;
};

#endif
