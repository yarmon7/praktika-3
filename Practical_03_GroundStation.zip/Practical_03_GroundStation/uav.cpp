#include "uav.h"

#include <algorithm>
#include <cmath>

double UAV::altitude() const { return altitude_; }
double UAV::battery() const { return battery_; }

void UAV::advance(double verticalCommand, double dt)
{
    // Учебная динамика высоты: управление задаёт вертикальную скорость.
    const double requested = std::clamp(verticalCommand,
                                       -max_vertical_speed(), max_vertical_speed());
    verticalSpeed_ += (requested - verticalSpeed_) * std::min(dt / response_time(), 1.0);
    altitude_ = std::max(0.0, altitude_ + verticalSpeed_ * dt);
    if (altitude_ == 0.0 && verticalSpeed_ < 0.0)
        verticalSpeed_ = 0.0;
    battery_ = std::max(0.0, battery_ - dt * (0.015 + 0.002 * std::abs(verticalSpeed_)));
}

void UAV::hold_position() { verticalSpeed_ = 0.0; }
void UAV::touch_down()
{
    altitude_ = 0.0;
    verticalSpeed_ = 0.0;
}

QString Quadcopter::type() const { return QStringLiteral("Квадрокоптер"); }
int Quadcopter::motor_count() const { return 4; }
double Quadcopter::max_vertical_speed() const { return 18.0; }
double Quadcopter::response_time() const { return 0.8; }

QString FixedWingUAV::type() const { return QStringLiteral("Самолётный БПЛА"); }
int FixedWingUAV::motor_count() const { return 1; }
double FixedWingUAV::max_vertical_speed() const { return 12.0; }
double FixedWingUAV::response_time() const { return 1.2; }
