#ifndef CHARTSCOMPAT_H
#define CHARTSCOMPAT_H

#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QLegend>
#include <QtCharts/QLineSeries>
#include <QtCharts/QValueAxis>

// Qt 5 размещает Charts в пространстве QtCharts, Qt 6 — в глобальном.
namespace Charts {
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
using QtCharts::QChart;
using QtCharts::QChartView;
using QtCharts::QLineSeries;
using QtCharts::QValueAxis;
#else
using ::QChart;
using ::QChartView;
using ::QLineSeries;
using ::QValueAxis;
#endif
}

#endif
