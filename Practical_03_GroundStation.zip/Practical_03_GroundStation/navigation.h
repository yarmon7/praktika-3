#ifndef NAVIGATION_H
#define NAVIGATION_H

#include <QObject>
#include <QString>

class NavigationSystem
{
public:
    virtual ~NavigationSystem() = default;
    virtual QString name() const = 0;
    bool is_valid() const;
    void set_valid(bool valid);

private:
    bool valid_ = true;
};

class GPSNavigation final : public NavigationSystem
{
public:
    QString name() const override;
};

class InertialNavigation final : public NavigationSystem
{
public:
    QString name() const override;
};

class VisualNavigation final : public NavigationSystem
{
public:
    QString name() const override;
};

// Приоритет GPS -> INS -> Visual целиком находится в модели.
class NavigationManager final : public QObject
{
    Q_OBJECT
public:
    explicit NavigationManager(QObject *parent = nullptr);
    bool update_active_system();
    QString active_name() const;
    void set_gps_valid(bool valid);
    void set_ins_valid(bool valid);
    void set_visual_valid(bool valid);
    void restore();

signals:
    void active_system_changed(const QString &name);

private:
    GPSNavigation gps_;
    InertialNavigation inertial_;
    VisualNavigation visual_;
    NavigationSystem *active_ = nullptr;
};

#endif
