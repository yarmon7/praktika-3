#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QApplication::setApplicationName(QStringLiteral("Наземная станция БПЛА"));
    QApplication::setStyle(QStringLiteral("Fusion"));
    MainWindow window;
    window.show();
    return app.exec();
}
