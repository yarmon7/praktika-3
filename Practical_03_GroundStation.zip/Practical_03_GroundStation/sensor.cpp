#include "sensor.h"

Sensor::Sensor(double value) : value_(value) {}
double Sensor::read() const { return value_; }
bool Sensor::is_ready() const { return ready_; }
void Sensor::set_ready(bool ready) { ready_ = ready; }

Gyroscope::Gyroscope(double value) : Sensor(value) {}
QString Gyroscope::name() const { return QStringLiteral("Гироскоп"); }
Accelerometer::Accelerometer(double value) : Sensor(value) {}
QString Accelerometer::name() const { return QStringLiteral("Акселерометр"); }
Barometer::Barometer(double value) : Sensor(value) {}
QString Barometer::name() const { return QStringLiteral("Барометр"); }
