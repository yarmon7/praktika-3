#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "autopilot.h"

#include <QComboBox>
#include <QDoubleSpinBox>
#include <QGraphicsPathItem>
#include <QGraphicsPolygonItem>
#include <QGraphicsScene>
#include <QHeaderView>
#include <QEvent>
#include <QLabel>
#include <QMessageBox>
#include <QPainter>
#include <QPainterPath>
#include <QPushButton>
#include <QResizeEvent>
#include <QSignalBlocker>
#include <QTimer>
#include <algorithm>
#include <cmath>

namespace {
const std::array<QColor, 2> aircraftColors = {QColor("#1769aa"), QColor("#d07816")};
const QString green = QStringLiteral("color: #177347; background: #e7f5ed; padding: 7px; border-radius: 5px;");
const QString yellow = QStringLiteral("color: #855c00; background: #fff2c6; padding: 5px; border-radius: 4px;");
const QString red = QStringLiteral("color: #ad2525; background: #fde8e8; padding: 7px; border-radius: 5px; font-weight: bold;");
const QString neutral = QStringLiteral("color: #48576b; background: #eaf0f6; padding: 7px; border-radius: 5px;");
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow), cycleTimer_(new QTimer(this)),
      autopilots_{new Autopilot(QStringLiteral("БПЛА-1"), std::make_unique<Quadcopter>(),
                               155.0, 0.0, this),
                  new Autopilot(QStringLiteral("БПЛА-2"), std::make_unique<FixedWingUAV>(),
                               115.0, 3.141592653589793, this)}
{
    ui->setupUi(this);
    uptime_.start();
    ui->labelBadge->setMaximumWidth(175);
    ui->headerLayout->setStretch(0, 1);
    views_ = {{
        {ui->labelAltitude, ui->labelError, ui->labelOutput, ui->labelRoll,
         ui->labelMode, ui->labelNavigation, ui->labelTarget},
        {ui->labelAltitude2, ui->labelError2, ui->labelOutput2, ui->labelRoll2,
         ui->labelMode2, ui->labelNavigation2, ui->labelTarget2}
    }};


    ui->tableFleet->setRowCount(2);
    ui->tableFleet->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableFleet->verticalHeader()->hide();
    ui->tableFleet->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableFleet->setSelectionBehavior(QAbstractItemView::SelectRows);
    for (int i = 0; i < 2; ++i) {
        // Тип аппарата берётся полиморфно из UAV::type(), а не из названия строки.
        const QStringList cells = {autopilots_[i]->name(), autopilots_[i]->vehicle_type(),
                                    QStringLiteral("100.0 %"), QStringLiteral("Стоп")};
        for (int column = 0; column < cells.size(); ++column)
            ui->tableFleet->setItem(i, column, new QTableWidgetItem(cells[column]));
        views_[i].navigation->setStyleSheet(green);
        views_[i].navigation->setToolTip(QStringLiteral("Активная система навигации"));
        views_[i].navigation->setMinimumHeight(30);
        views_[i].navigation->setMaximumWidth(70);
    }
    prepare_chart();
    prepare_scene();

    cycleTimer_->setObjectName(QStringLiteral("cycleTimer"));
    cycleTimer_->setTimerType(Qt::PreciseTimer);
    cycleTimer_->setInterval(100);
    // Вариант 3 задания 1: ОДИН timeout и ДВА независимых автопилота.
    connect(cycleTimer_, &QTimer::timeout, autopilots_[0], &Autopilot::run_cycle);
    connect(cycleTimer_, &QTimer::timeout, autopilots_[1], &Autopilot::run_cycle);
    for (int i = 0; i < 2; ++i) {
        auto *autopilot = autopilots_[i];
        // Один сигнал телеметрии подключён к трём отдельным слотам представления.
        connect(autopilot, &Autopilot::telemetry_updated, this, &MainWindow::update_labels);
        connect(autopilot, &Autopilot::telemetry_updated, this, &MainWindow::update_fleet);
        connect(autopilot, &Autopilot::telemetry_updated, this, &MainWindow::update_chart);
        connect(autopilot, &Autopilot::position_updated, this, &MainWindow::update_position);
        connect(autopilot, &Autopilot::fault_detected, this, &MainWindow::on_fault);
        connect(autopilot, &Autopilot::navigation_changed, this, &MainWindow::on_navigation);
        connect(autopilot, &Autopilot::mode_changed, this, [this, autopilot](const QString &mode) {
            refresh_modes();
            update_status();
            add_log(autopilot->name() + QStringLiteral(": режим — ") + mode);
        });
        connect(autopilot, &Autopilot::target_changed, this, [this, i](double target) {
            views_[i].target->setText(QString::number(target, 'f', 1) + QStringLiteral(" м"));
            sync_target_editor();
        });
    }
    connect(ui->btnStart, &QPushButton::clicked, this, &MainWindow::start_cycles);
    connect(ui->btnPause, &QPushButton::clicked, this, &MainWindow::pause_cycles);
    connect(ui->btnReset, &QPushButton::clicked, this, &MainWindow::reset_faults);
    connect(ui->btnTakeoff, &QPushButton::clicked, this, &MainWindow::takeoff);
    connect(ui->btnLand, &QPushButton::clicked, this, &MainWindow::land);
    connect(ui->btnStop, &QPushButton::clicked, this, &MainWindow::stop);
    connect(ui->btnFaultSensor, &QPushButton::clicked, this, &MainWindow::fault_sensor);
    connect(ui->btnFaultGps, &QPushButton::clicked, this, &MainWindow::fault_gps);
    connect(ui->btnRestoreGps, &QPushButton::clicked, this, &MainWindow::restore_gps);
    connect(ui->spinTarget, QOverload<double>::of(&QDoubleSpinBox::valueChanged),
            this, &MainWindow::apply_target);
    connect(ui->comboAircraft, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &MainWindow::sync_target_editor);
    refresh_modes();
    update_status();
    add_log(QStringLiteral("Станция готова. Два аппарата, общий таймер 100 мс."));
}

MainWindow::~MainWindow() { delete ui; }

int MainWindow::index_of(const QString &name) const
{
    for (int i = 0; i < 2; ++i)
        if (autopilots_[i]->name() == name)
            return i;
    return -1;
}

bool MainWindow::selected(int index) const
{
    return ui->comboAircraft->currentIndex() == 0 || ui->comboAircraft->currentIndex() == index + 1;
}

void MainWindow::prepare_chart()
{
    chart_ = new Charts::QChart;
    chart_->setBackgroundRoundness(0);
    chart_->setBackgroundBrush(Qt::white);
    chart_->setPlotAreaBackgroundBrush(QColor("#fbfcfe"));
    chart_->setPlotAreaBackgroundVisible(true);
    chart_->legend()->setFont(QFont(font().family(), 9));
    chart_->setAnimationOptions(Charts::QChart::NoAnimation);
    chart_->setMargins(QMargins(2, 2, 2, 2));
    timeAxis_ = new Charts::QValueAxis(chart_);
    valueAxis_ = new Charts::QValueAxis(chart_);
    timeAxis_->setTitleText(QStringLiteral("Время модели, с"));
    valueAxis_->setTitleText(QStringLiteral("Метры"));
    timeAxis_->setRange(0.0, 30.0);
    valueAxis_->setRange(-60.0, 340.0);
    timeAxis_->setTickCount(5);
    valueAxis_->setTickCount(5);
    timeAxis_->setGridLinePen(QPen(QColor("#e6edf5")));
    valueAxis_->setGridLinePen(QPen(QColor("#e6edf5")));
    timeAxis_->setLabelFormat("%.0f");
    valueAxis_->setLabelFormat("%.0f");
    chart_->addAxis(timeAxis_, Qt::AlignBottom);
    chart_->addAxis(valueAxis_, Qt::AlignLeft);
    for (int i = 0; i < 2; ++i) {
        views_[i].altitudeSeries = new Charts::QLineSeries(chart_);
        views_[i].errorSeries = new Charts::QLineSeries(chart_);
        views_[i].altitudeSeries->setName(QStringLiteral("%1: высота").arg(i + 1));
        views_[i].errorSeries->setName(QStringLiteral("%1: ошибка").arg(i + 1));
        views_[i].altitudeSeries->setPen(QPen(aircraftColors[i], 2.2));
        views_[i].errorSeries->setPen(QPen(aircraftColors[i], 1.5, Qt::DashLine));
        for (auto *series : {views_[i].altitudeSeries, views_[i].errorSeries}) {
            chart_->addSeries(series);
            series->attachAxis(timeAxis_);
            series->attachAxis(valueAxis_);
        }
    }
    chart_->legend()->setVisible(true);
    chart_->legend()->setAlignment(Qt::AlignBottom);
    auto *chartView = new Charts::QChartView(chart_, ui->chartContainer);
    chartView->setObjectName(QStringLiteral("chartView"));
    chartView->setRenderHint(QPainter::Antialiasing);
    chartView->setFrameShape(QFrame::NoFrame);
    ui->chartLayout->addWidget(chartView);
}

void MainWindow::prepare_scene()
{
    scene_ = new QGraphicsScene(this);
    scene_->setSceneRect(-205, -205, 410, 410);
    scene_->setBackgroundBrush(QColor("#fcfdff"));
    ui->graphicsView->setScene(scene_);
    ui->graphicsView->viewport()->installEventFilter(this);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);
    for (int p = -200; p <= 200; p += 50) {
        scene_->addLine(p, -200, p, 200, QPen(QColor("#e4eaf1")));
        scene_->addLine(-200, p, 200, p, QPen(QColor("#e4eaf1")));
    }
    for (int i = 0; i < 2; ++i) {
        const double r = autopilots_[i]->route_radius();
        scene_->addEllipse(-r, -r, r * 2, r * 2,
                            QPen(aircraftColors[i].lighter(150), 1, Qt::DashLine));
        for (const QPointF &p : {QPointF(r, 0), QPointF(0, r), QPointF(-r, 0), QPointF(0, -r)})
            scene_->addEllipse(p.x() - 3, p.y() - 3, 6, 6,
                                QPen(aircraftColors[i]), QBrush(Qt::white));
        views_[i].trajectory = scene_->addPath(QPainterPath(), QPen(aircraftColors[i], 2));
        views_[i].trajectory->setData(0, QStringLiteral("trajectory%1").arg(i));
        QPolygonF shape;
        if (i == 0)
            shape << QPointF(0, -13) << QPointF(11, 9) << QPointF(0, 4) << QPointF(-11, 9);
        else
            shape << QPointF(0, -16) << QPointF(4, -3) << QPointF(15, 5) << QPointF(4, 4)
                  << QPointF(4, 13) << QPointF(-4, 13) << QPointF(-4, 4)
                  << QPointF(-15, 5) << QPointF(-4, -3);
        views_[i].marker = scene_->addPolygon(shape, QPen(Qt::white, 1.2), QBrush(aircraftColors[i]));
        views_[i].marker->setZValue(2);
        views_[i].marker->setData(0, QStringLiteral("marker%1").arg(i));
        const QPointF position = autopilots_[i]->position();
        update_position(autopilots_[i]->name(), position.x(), position.y(), 0.0);
    }
    ui->graphicsView->fitInView(scene_->sceneRect(), Qt::KeepAspectRatio);
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    QMainWindow::resizeEvent(event);
    if (scene_)
        ui->graphicsView->fitInView(scene_->sceneRect(), Qt::KeepAspectRatio);
}

bool MainWindow::eventFilter(QObject *watched, QEvent *event)
{
    if (scene_ && watched == ui->graphicsView->viewport() && event->type() == QEvent::Resize)
        ui->graphicsView->fitInView(scene_->sceneRect(), Qt::KeepAspectRatio);
    return QMainWindow::eventFilter(watched, event);
}

void MainWindow::start_cycles()
{
    if (faultActive_) {
        add_log(QStringLiteral("Пуск заблокирован: сначала устраните отказ кнопкой «Сброс»."));
        return;
    }
    for (auto *autopilot : autopilots_)
        autopilot->resume();
    paused_ = false;
    cycleTimer_->start();
    refresh_modes();
    update_status();
    add_log(QStringLiteral("Старт: опрос обоих аппаратов, 10 Гц."));
}

void MainWindow::pause_cycles()
{
    paused_ = true;
    cycleTimer_->stop();
    update_status();
    add_log(QStringLiteral("Пауза: состояние модели сохранено."));
}

void MainWindow::reset_faults()
{
    faultActive_ = false;
    warningShown_ = false;
    faultReason_.clear();
    for (auto *autopilot : autopilots_)
        autopilot->reset_faults();
    paused_ = false;
    cycleTimer_->start();
    refresh_modes();
    update_status();
    add_log(QStringLiteral("Сброс: сенсоры и GPS восстановлены, цикл продолжен."));
}

void MainWindow::start_timer_for_commands()
{
    if (!faultActive_) {
        paused_ = false;
        cycleTimer_->start();
    }
    refresh_modes();
    update_status();
}

void MainWindow::takeoff()
{
    if (faultActive_)
        return;
    for (int i = 0; i < 2; ++i)
        if (selected(i))
            autopilots_[i]->command_takeoff();
    start_timer_for_commands();
}

void MainWindow::land()
{
    if (faultActive_)
        return;
    for (int i = 0; i < 2; ++i)
        if (selected(i))
            autopilots_[i]->command_land();
    start_timer_for_commands();
}

void MainWindow::stop()
{
    paused_ = false;
    for (int i = 0; i < 2; ++i)
        if (selected(i))
            autopilots_[i]->command_stop();
    if (std::none_of(autopilots_.begin(), autopilots_.end(),
                     [](Autopilot *a) { return a->is_running(); }))
        cycleTimer_->stop();
    refresh_modes();
    update_status();
}

void MainWindow::apply_target(double altitude)
{
    for (int i = 0; i < 2; ++i)
        if (selected(i))
            autopilots_[i]->set_target_altitude(altitude);
    add_log(QStringLiteral("Целевая высота выбранных аппаратов: %1 м.").arg(altitude, 0, 'f', 0));
}

void MainWindow::sync_target_editor()
{
    const QSignalBlocker blocker(ui->spinTarget);
    const int index = std::max(0, ui->comboAircraft->currentIndex() - 1);
    ui->spinTarget->setValue(autopilots_[index]->target_altitude());
}

void MainWindow::fault_sensor()
{
    for (int i = 0; i < 2; ++i)
        if (selected(i))
            autopilots_[i]->set_gyroscope_ready(false);
    add_log(QStringLiteral("Гироскоп выбранных аппаратов: Not ready; проверка на следующем тике."));
}

void MainWindow::fault_gps()
{
    for (int i = 0; i < 2; ++i)
        if (selected(i))
            autopilots_[i]->set_gps_valid(false);
    add_log(QStringLiteral("GPS выбранных аппаратов отключён."));
}

void MainWindow::restore_gps()
{
    for (int i = 0; i < 2; ++i)
        if (selected(i))
            autopilots_[i]->set_gps_valid(true);
    add_log(QStringLiteral("GPS выбранных аппаратов восстановлен."));
}

void MainWindow::update_labels(const QString &name, double altitude, double error, double control)
{
    const int i = index_of(name);
    if (i < 0)
        return;
    views_[i].altitude->setText(QString::number(altitude, 'f', 1) + QStringLiteral(" м"));
    views_[i].error->setText(QString::number(error, 'f', 1) + QStringLiteral(" м"));
    views_[i].output->setText(QString::number(control, 'f', 2) + QStringLiteral(" м/с"));
}

void MainWindow::update_fleet(const QString &name, double, double, double)
{
    const int i = index_of(name);
    if (i < 0)
        return;
    ui->tableFleet->item(i, 2)->setText(QString::number(autopilots_[i]->battery(), 'f', 1) + " %");
    ui->tableFleet->item(i, 3)->setText(autopilots_[i]->mode_name());
}

void MainWindow::update_chart(const QString &name, double altitude, double error, double)
{
    const int i = index_of(name);
    if (i < 0)
        return;
    const double t = autopilots_[i]->elapsed_seconds();
    views_[i].altitudeSeries->append(t, altitude);
    views_[i].errorSeries->append(t, error);
    // Скользящее окно графика ограничивает память при долгом запуске.
    for (auto *series : {views_[i].altitudeSeries, views_[i].errorSeries})
        if (series->count() > 600)
            series->removePoints(0, series->count() - 600);
    const double latestTime = std::max(autopilots_[0]->elapsed_seconds(), autopilots_[1]->elapsed_seconds());
    timeAxis_->setRange(std::max(0.0, latestTime - 60.0), std::max(30.0, latestTime));
    valueAxis_->setRange(std::min(valueAxis_->min(), error - 20.0),
                         std::max({valueAxis_->max(), altitude + 40.0, error + 20.0}));
}

void MainWindow::update_position(const QString &name, double x, double y, double roll)
{
    const int i = index_of(name);
    if (i < 0)
        return;
    auto &view = views_[i];
    view.marker->setPos(x, -y);
    view.marker->setRotation(roll);
    view.roll->setText(QString::number(roll, 'f', 1) + QStringLiteral("°"));
    // Путь и маркер созданы один раз. Продлеваем тот же QGraphicsPathItem.
    QPainterPath path = view.trajectory->path();
    if (!view.hasPosition) {
        path.moveTo(x, -y);
        view.hasPosition = true;
    } else {
        path.lineTo(x, -y);
    }
    view.trajectory->setPath(path);
}

void MainWindow::on_fault(const QString &name, const QString &reason)
{
    faultActive_ = true;
    faultReason_ = name + QStringLiteral(": ") + reason;
    cycleTimer_->stop();
    // Останавливаем и второй слот уже начавшегося timeout: вся станция в failsafe.
    for (auto *autopilot : autopilots_)
        autopilot->suspend();
    refresh_modes();
    update_status();
    add_log(QStringLiteral("АВАРИЯ — ") + faultReason_);
    ui->detailsTabs->setCurrentWidget(ui->eventsPage);
    QTimer::singleShot(0, ui->listEvents, &QListWidget::scrollToBottom);
    if (!warningShown_) {
        warningShown_ = true;
        auto *warning = new QMessageBox(QMessageBox::Warning, QStringLiteral("Авария БПЛА"),
                                        faultReason_ + QStringLiteral("\nЦикл остановлен. Нажмите «Сброс» для восстановления."),
                                        QMessageBox::Ok, this);
        warning->setObjectName(QStringLiteral("faultWarning"));
        warning->setAttribute(Qt::WA_DeleteOnClose);
        warning->open();
    }
}

void MainWindow::on_navigation(const QString &name, const QString &system)
{
    const int i = index_of(name);
    if (i < 0)
        return;
    views_[i].navigation->setText(system);
    views_[i].navigation->setStyleSheet(system == QStringLiteral("GPS") ? green : yellow);
    add_log(name + QStringLiteral(": активная навигация — ") + system);
}

void MainWindow::refresh_modes()
{
    for (int i = 0; i < 2; ++i) {
        views_[i].mode->setText(autopilots_[i]->mode_name());
        ui->tableFleet->item(i, 3)->setText(autopilots_[i]->mode_name());
    }
}

void MainWindow::update_status()
{
    if (faultActive_) {
        ui->labelStatus->setText(QStringLiteral("АВАРИЯ / FAULT — ") + faultReason_);
        ui->labelStatus->setStyleSheet(red);
    } else if (cycleTimer_->isActive()) {
        ui->labelStatus->setText(QStringLiteral("Работает / Running · 10 Гц | %1: %2 | %3: %4")
            .arg(autopilots_[0]->name(), autopilots_[0]->mode_name(),
                 autopilots_[1]->name(), autopilots_[1]->mode_name()));
        ui->labelStatus->setStyleSheet(green);
    } else if (paused_) {
        ui->labelStatus->setText(QStringLiteral("Пауза / Paused · состояние аппаратов сохранено"));
        ui->labelStatus->setStyleSheet(neutral);
    } else {
        ui->labelStatus->setText(QStringLiteral("Остановлено / Stopped · нажмите «Старт» или «Взлёт»"));
        ui->labelStatus->setStyleSheet(neutral);
    }
    ui->btnStart->setEnabled(!faultActive_ && !cycleTimer_->isActive());
    ui->btnPause->setEnabled(!faultActive_ && cycleTimer_->isActive());
    ui->btnTakeoff->setEnabled(!faultActive_);
    ui->btnLand->setEnabled(!faultActive_);
    ui->spinTarget->setEnabled(!faultActive_);
}

void MainWindow::add_log(const QString &text)
{
    ui->listEvents->addItem(QStringLiteral("[%1 с] %2").arg(uptime_.elapsed() / 1000.0, 0, 'f', 1).arg(text));
    if (ui->listEvents->count() > 300)
        delete ui->listEvents->takeItem(0);
    ui->listEvents->scrollToBottom();
    ui->detailsTabs->setTabText(1, QStringLiteral("Журнал событий · %1").arg(ui->listEvents->count()));
}
