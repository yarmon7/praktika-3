#ifndef CONTROLLER_H
#define CONTROLLER_H

class FlightController
{
public:
    virtual ~FlightController() = default;
    virtual double calculate(double error, double dt, double limit) = 0;
    virtual void reset() = 0;
};

class PIDController final : public FlightController
{
public:
    PIDController(double kp, double ki, double kd);
    double calculate(double error, double dt, double limit) override;
    void reset() override;

private:
    double kp_;
    double ki_;
    double kd_;
    double integral_ = 0.0;
    double previousError_ = 0.0;
    bool firstCycle_ = true;
};

#endif
