#ifndef AUTOPILOT_H
#define AUTOPILOT_H

#include <QObject>
#include <QPointF>
#include <memory>
#include <vector>

#include "controller.h"
#include "navigation.h"
#include "sensor.h"
#include "uav.h"

class Autopilot final : public QObject
{
    Q_OBJECT
public:
    enum class Mode { Stopped, Hold, Takeoff, Landing, Landed, Fault };
    Q_ENUM(Mode)

    Autopilot(QString name, std::unique_ptr<UAV> vehicle, double routeRadius,
              double initialAngle, QObject *parent = nullptr);

    QString name() const;
    QString vehicle_type() const;
    QString mode_name() const;
    QString active_navigation() const;
    Mode mode() const;
    double altitude() const;
    double target_altitude() const;
    double elapsed_seconds() const;
    double battery() const;
    double route_radius() const;
    QPointF position() const;
    bool has_fault() const;
    bool is_running() const;

    void resume();
    void suspend();
    void set_target_altitude(double altitude);
    void set_gyroscope_ready(bool ready);
    void set_gps_valid(bool valid);
    void reset_faults();

public slots:
    void run_cycle();
    void command_takeoff();
    void command_land();
    void command_stop();

signals:
    void telemetry_updated(const QString &name, double altitude, double error, double control);
    void position_updated(const QString &name, double x, double y, double roll);
    void fault_detected(const QString &name, const QString &reason);
    void mode_changed(const QString &mode);
    void navigation_changed(const QString &name, const QString &system);
    void target_changed(double altitude);

private:
    void set_mode(Mode mode);
    void fail(const QString &reason);
    void publish_telemetry();

    QString name_;
    std::unique_ptr<UAV> vehicle_;
    std::vector<std::unique_ptr<Sensor>> sensors_;
    NavigationManager *navigation_;
    std::unique_ptr<FlightController> controller_;
    Mode mode_ = Mode::Stopped;
    Mode modeBeforeFault_ = Mode::Hold;
    bool running_ = false;
    bool fault_ = false;
    double targetAltitude_ = 200.0;
    double elapsed_ = 0.0;
    double control_ = 0.0;
    double radius_;
    double angle_;
    static constexpr double dt_ = 0.1;
};

#endif
