#include "autopilot.h"

#include <algorithm>
#include <cmath>
#include <utility>

Autopilot::Autopilot(QString name, std::unique_ptr<UAV> vehicle, double routeRadius,
                     double initialAngle, QObject *parent)
    : QObject(parent), name_(std::move(name)), vehicle_(std::move(vehicle)),
      navigation_(new NavigationManager(this)),
      controller_(std::make_unique<PIDController>(0.75, 0.008, 0.15)),
      radius_(routeRadius), angle_(initialAngle)
{
    sensors_.push_back(std::make_unique<Gyroscope>());
    sensors_.push_back(std::make_unique<Accelerometer>());
    sensors_.push_back(std::make_unique<Barometer>());
    connect(navigation_, &NavigationManager::active_system_changed, this,
            [this](const QString &system) { emit navigation_changed(name_, system); });
}

QString Autopilot::name() const { return name_; }
QString Autopilot::vehicle_type() const
{
    return vehicle_ ? vehicle_->type() : QStringLiteral("Аппарат не задан");
}
Autopilot::Mode Autopilot::mode() const { return mode_; }
QString Autopilot::mode_name() const
{
    switch (mode_) {
    case Mode::Stopped: return QStringLiteral("Стоп");
    case Mode::Hold: return QStringLiteral("Удержание высоты");
    case Mode::Takeoff: return QStringLiteral("Взлёт");
    case Mode::Landing: return QStringLiteral("Посадка");
    case Mode::Landed: return QStringLiteral("На земле");
    case Mode::Fault: return QStringLiteral("Авария");
    }
    return {};
}
QString Autopilot::active_navigation() const { return navigation_->active_name(); }
double Autopilot::altitude() const { return vehicle_ ? vehicle_->altitude() : 0.0; }
double Autopilot::target_altitude() const { return targetAltitude_; }
double Autopilot::elapsed_seconds() const { return elapsed_; }
double Autopilot::battery() const { return vehicle_ ? vehicle_->battery() : 0.0; }
double Autopilot::route_radius() const { return radius_; }
QPointF Autopilot::position() const
{
    return QPointF(radius_ * std::cos(angle_), radius_ * std::sin(angle_));
}
bool Autopilot::has_fault() const { return fault_; }
bool Autopilot::is_running() const { return running_; }

void Autopilot::set_mode(Mode mode)
{
    if (mode_ == mode)
        return;
    mode_ = mode;
    emit mode_changed(mode_name());
}

void Autopilot::resume()
{
    if (fault_)
        return;
    running_ = true;
    if (mode_ == Mode::Stopped)
        set_mode(Mode::Hold);
}

void Autopilot::suspend() { running_ = false; }

void Autopilot::set_target_altitude(double altitude)
{
    if (fault_ || !std::isfinite(altitude))
        return;
    targetAltitude_ = std::clamp(altitude, 0.0, 500.0);
    controller_->reset();
    set_mode(Mode::Hold);
    emit target_changed(targetAltitude_);
    publish_telemetry();
}

void Autopilot::set_gyroscope_ready(bool ready) { sensors_.front()->set_ready(ready); }
void Autopilot::set_gps_valid(bool valid) { navigation_->set_gps_valid(valid); }

void Autopilot::command_takeoff()
{
    if (fault_)
        return;
    targetAltitude_ = 200.0;
    controller_->reset();
    running_ = true;
    set_mode(Mode::Takeoff);
    emit target_changed(targetAltitude_);
    publish_telemetry();
}

void Autopilot::command_land()
{
    if (fault_)
        return;
    targetAltitude_ = 0.0;
    controller_->reset();
    running_ = true;
    set_mode(Mode::Landing);
    emit target_changed(targetAltitude_);
    publish_telemetry();
}

void Autopilot::command_stop()
{
    if (fault_)
        return;
    running_ = false;
    control_ = 0.0;
    targetAltitude_ = altitude();
    if (vehicle_)
        vehicle_->hold_position();
    controller_->reset();
    set_mode(Mode::Stopped);
    emit target_changed(targetAltitude_);
    publish_telemetry();
}

void Autopilot::fail(const QString &reason)
{
    if (fault_)
        return;
    modeBeforeFault_ = mode_;
    fault_ = true;
    running_ = false;
    control_ = 0.0;
    set_mode(Mode::Fault);
    emit fault_detected(name_, reason);
}

void Autopilot::reset_faults()
{
    for (const auto &sensor : sensors_)
        sensor->set_ready(true);
    navigation_->restore();
    const bool wasFault = fault_;
    fault_ = false;
    if (wasFault)
        set_mode(modeBeforeFault_);
    controller_->reset();
    resume();
}

void Autopilot::publish_telemetry()
{
    emit telemetry_updated(name_, altitude(), targetAltitude_ - altitude(), control_);
}

void Autopilot::run_cycle()
{
    if (!running_ || fault_)
        return;
    if (!vehicle_) {
        fail(QStringLiteral("Аппарат не задан"));
        return;
    }
    for (const auto &sensor : sensors_) {
        if (!sensor || !sensor->is_ready()) {
            fail(QStringLiteral("Отказ сенсора: %1").arg(sensor ? sensor->name()
                                                            : QStringLiteral("неизвестный")));
            return;
        }
    }
    if (!navigation_->update_active_system()) {
        fail(QStringLiteral("Нет валидной навигационной системы"));
        return;
    }

    control_ = controller_->calculate(targetAltitude_ - altitude(), dt_,
                                       vehicle_->max_vertical_speed());
    vehicle_->advance(control_, dt_);
    elapsed_ += dt_;
    if (mode_ == Mode::Takeoff && std::abs(targetAltitude_ - altitude()) < 0.5)
        set_mode(Mode::Hold);
    if (mode_ == Mode::Landing && altitude() < 0.15) {
        // Завершение посадки: дальнейшее движение по маршруту прекращается.
        vehicle_->touch_down();
        control_ = 0.0;
        set_mode(Mode::Landed);
    }

    double roll = 0.0;
    if (altitude() > 0.15 && mode_ != Mode::Landed) {
        angle_ += 0.28 * dt_;
        roll = 22.0 * std::sin(angle_ * 1.4);
    }
    publish_telemetry();
    const QPointF currentPosition = position();
    emit position_updated(name_, currentPosition.x(), currentPosition.y(), roll);
}
