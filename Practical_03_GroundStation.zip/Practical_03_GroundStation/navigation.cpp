#include "navigation.h"

bool NavigationSystem::is_valid() const { return valid_; }
void NavigationSystem::set_valid(bool valid) { valid_ = valid; }
QString GPSNavigation::name() const { return QStringLiteral("GPS"); }
QString InertialNavigation::name() const { return QStringLiteral("INS"); }
QString VisualNavigation::name() const { return QStringLiteral("Visual"); }

NavigationManager::NavigationManager(QObject *parent) : QObject(parent), active_(&gps_) {}

bool NavigationManager::update_active_system()
{
    NavigationSystem *next = nullptr;
    for (NavigationSystem *system : {static_cast<NavigationSystem *>(&gps_),
                                     static_cast<NavigationSystem *>(&inertial_),
                                     static_cast<NavigationSystem *>(&visual_)}) {
        if (system->is_valid()) {
            next = system;
            break;
        }
    }
    if (next != active_) {
        active_ = next;
        emit active_system_changed(active_name());
    }
    return active_ != nullptr;
}

QString NavigationManager::active_name() const
{
    return active_ ? active_->name() : QStringLiteral("Нет навигации");
}

void NavigationManager::set_gps_valid(bool valid) { gps_.set_valid(valid); }
void NavigationManager::set_ins_valid(bool valid) { inertial_.set_valid(valid); }
void NavigationManager::set_visual_valid(bool valid) { visual_.set_valid(valid); }
void NavigationManager::restore()
{
    gps_.set_valid(true);
    inertial_.set_valid(true);
    visual_.set_valid(true);
    update_active_system();
}
