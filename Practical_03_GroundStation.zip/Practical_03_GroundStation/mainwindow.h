#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QElapsedTimer>
#include <QMainWindow>
#include <array>

#include "chartscompat.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class Autopilot;
class QLabel;
class QTimer;
class QGraphicsScene;
class QGraphicsPathItem;
class QGraphicsPolygonItem;

class MainWindow final : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

protected:
    void resizeEvent(QResizeEvent *event) override;
    bool eventFilter(QObject *watched, QEvent *event) override;

private slots:
    void start_cycles();
    void pause_cycles();
    void reset_faults();
    void takeoff();
    void land();
    void stop();
    void apply_target(double altitude);
    void fault_sensor();
    void fault_gps();
    void restore_gps();
    void update_labels(const QString &name, double altitude, double error, double control);
    void update_fleet(const QString &name, double altitude, double error, double control);
    void update_chart(const QString &name, double altitude, double error, double control);
    void update_position(const QString &name, double x, double y, double roll);
    void on_fault(const QString &name, const QString &reason);
    void on_navigation(const QString &name, const QString &system);
    void update_status();
    void sync_target_editor();

private:
    struct AircraftView {
        QLabel *altitude;
        QLabel *error;
        QLabel *output;
        QLabel *roll;
        QLabel *mode;
        QLabel *navigation;
        QLabel *target;
        Charts::QLineSeries *altitudeSeries = nullptr;
        Charts::QLineSeries *errorSeries = nullptr;
        QGraphicsPolygonItem *marker = nullptr;
        QGraphicsPathItem *trajectory = nullptr;
        bool hasPosition = false;
    };

    int index_of(const QString &name) const;
    bool selected(int index) const;
    void prepare_chart();
    void prepare_scene();
    void refresh_modes();
    void add_log(const QString &text);
    void start_timer_for_commands();

    Ui::MainWindow *ui;
    QTimer *cycleTimer_;
    std::array<Autopilot *, 2> autopilots_;
    std::array<AircraftView, 2> views_;
    Charts::QChart *chart_ = nullptr;
    Charts::QValueAxis *timeAxis_ = nullptr;
    Charts::QValueAxis *valueAxis_ = nullptr;
    QGraphicsScene *scene_ = nullptr;
    QElapsedTimer uptime_;
    bool paused_ = false;
    bool faultActive_ = false;
    bool warningShown_ = false;
    QString faultReason_;
};

#endif
