#ifndef SENSOR_H
#define SENSOR_H

#include <QString>

class Sensor
{
public:
    explicit Sensor(double value);
    virtual ~Sensor() = default;
    virtual QString name() const = 0;
    double read() const;
    bool is_ready() const;
    void set_ready(bool ready);

private:
    double value_;
    bool ready_ = true;
};

class Gyroscope final : public Sensor
{
public:
    explicit Gyroscope(double value = 1.2);
    QString name() const override;
};

class Accelerometer final : public Sensor
{
public:
    explicit Accelerometer(double value = 9.81);
    QString name() const override;
};

class Barometer final : public Sensor
{
public:
    explicit Barometer(double value = 1012.5);
    QString name() const override;
};

#endif
